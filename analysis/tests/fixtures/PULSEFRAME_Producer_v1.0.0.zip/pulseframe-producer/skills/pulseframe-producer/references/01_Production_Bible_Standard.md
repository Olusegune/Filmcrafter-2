# PULSEFRAME Producer — Production Bible Standard

The Production Bible is the canonical source of truth for a music-video project.

## Required sections for a full build
1. Project identity
2. Song identity and known timing
3. Creative concept
4. Narrative / emotional arc
5. Visual medium and style lane
6. Character roster
7. Character locked identity traits
8. Wardrobe plan
9. Props
10. Environments / sets
11. Color language
12. Lighting philosophy
13. Performance philosophy
14. Choreography philosophy
15. Camera language
16. Editing rhythm
17. Continuity rules
18. Known unknowns / assumptions

## Lock hierarchy
Production-level locks override general creative variation.
Scene-level locks may override production defaults.
Shot-level overrides are allowed only when explicitly documented.

## Locked vs flexible
Every important production asset should separate:

### LOCKED
Features that must not drift.

### FLEXIBLE
Features that may vary without breaking continuity.

## Character locks
Typical locks:
- face / head shape
- hair
- body type / scale
- key colors
- signature silhouette
- permanent accessories
- age presentation
- material/fur/skin identity

## Environment locks
Typical locks:
- room geometry
- landmark locations
- doors/windows
- major furniture
- key practical lights
- recurring signage
- spatial relationships

## Camera continuity
Record enough information to prevent accidental orientation reversal:
- camera side
- performer screen position
- travel direction
- eyeline
- relevant axis
- entrance / exit direction

## Change log
When a canonical rule changes, record:
- what changed
- why
- effective scene / shot
- assets requiring update
