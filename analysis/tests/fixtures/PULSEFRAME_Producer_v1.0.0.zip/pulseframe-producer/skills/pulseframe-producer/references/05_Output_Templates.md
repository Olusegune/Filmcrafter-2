# PULSEFRAME Producer — Output Templates

## Producer Summary
- Project:
- Concept:
- Visual lane:
- Production philosophy:
- Main risk:
- Recommended next action:

## Character Record
- Character ID:
- Name:
- Role:
- Canonical reference:
- Identity locks:
- Wardrobe IDs:
- Performance language:
- Choreography classification:
- Continuity notes:

## Environment Record
- Environment ID:
- Name:
- Story function:
- Spatial anchors:
- Lighting:
- Palette:
- Characters using location:
- Continuity locks:

## Shot Record
- Shot ID:
- Sequence:
- Time:
- Song section:
- Lyric cue:
- Environment:
- Characters:
- Wardrobe:
- Props:
- Action:
- Performance:
- Choreography:
- Framing:
- Camera:
- Lighting:
- Continuity:
- Reference assets:
- Transition:

## QA Record
- Finding ID:
- Severity:
- Category:
- Asset/shot:
- Issue:
- Evidence:
- Suggested fix:
- Blocks readiness: yes/no
