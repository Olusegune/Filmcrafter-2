# PULSEFRAME Producer — Choreography Package Standard

## Purpose
Choreography deliverables must be useful to both a human director and PULSEFRAME.

Every important movement sequence should have:
1. a visual choreography sheet
2. a written movement specification
3. timing relationships
4. performer identity
5. continuity / transition notes

## Performer classification
Before designing choreography, classify each character:
- no choreography
- ambient/natural motion
- performance blocking
- gesture performance
- featured dance
- ensemble dance
- non-human movement vocabulary

## Visual choreography sheet
Recommended: 6–10 beats.
Each beat:
- number
- short memorable name
- strong silhouette
- direction arrows
- consistent wardrobe
- consistent character identity
- clean background
- readable progression

Avoid:
- redundant poses
- physically impossible transitions
- generic “dance pose” repetition
- inconsistent proportions
- unmotivated costume changes

## Written movement block

### MOVE ID
Stable machine-readable ID, e.g. `move_child_verse1_03`.

### MOVE NAME
Memorable human-readable name.

### PERFORMER
Canonical character ID.

### SONG RELATIONSHIP
- section
- lyric cue
- start/end time if known
- beat/bar only if actually known
- accent / hold / pickup notes

### START POSE
Body weight, feet, torso, arms, gaze.

### ACTION
Describe the motion in executable order.

### BODY CHANNELS
- feet / locomotion
- hips / center
- torso
- arms/hands
- head/gaze
- expression

### ENERGY
1–10 plus qualitative note.

### END POSE
Define the transition-ready final state.

### TRAVEL
Direction and distance.

### CAMERA RELATIONSHIP
Front, 3/4, side, orbit, follow, wide, etc.

### TRANSITION
How it enters the next move.

## Group choreography
For ensembles include:
- formation diagram / description
- performer positions
- hero performer
- symmetry/asymmetry
- entrance/exit paths
- formation changes
- interaction points
- camera coverage

## Non-human performers
Do not map human dance literally onto non-human anatomy.
Design movement around the character’s physical capabilities and personality.
