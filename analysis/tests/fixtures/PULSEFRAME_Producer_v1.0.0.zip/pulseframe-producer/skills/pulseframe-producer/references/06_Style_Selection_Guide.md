# PULSEFRAME Producer — Style Selection Guide

Ask about style only when not already clear.

## Useful style lanes
- stylized 3D animated feature
- graphic 3D
- painterly 2D/3D hybrid
- clean graphic 2D
- anime-inspired cinematic
- hand-painted storybook
- ink-and-wash
- stop motion
- clay / tactile maquette
- cut-paper theatre
- editorial collage
- photoreal cinematic
- grounded documentary
- retro-futurist
- Afrofuturist
- surreal music-video editorial
- mixed media

## Always translate style into execution
Describe:
- silhouette language
- materials
- texture
- color
- lighting
- facial design
- background treatment
- motion character
- camera feel
- editing feel

Avoid depending on a studio/artist name alone.

## Motion style matters
The same still-image style can animate differently.
Define:
- pose-to-pose vs fluid
- snappy vs weighted
- restrained vs elastic
- realistic vs graphic
- camera kinetic level
- secondary motion intensity
