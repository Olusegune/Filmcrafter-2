# PULSEFRAME Producer — Asset Package Standard

## Character package
Create only as much as the role requires.

Hero character:
- canonical master sheet
- turnaround
- expressions
- poses
- wardrobe
- accessories
- color palette
- scale/height reference
- continuity anchors

Supporting character:
- master sheet
- essential views
- core expression/pose guidance

Extra/background:
- identity card may be sufficient

## Wardrobe
For each outfit:
- wardrobe ID
- owner character
- garment breakdown
- footwear
- accessories
- palette
- materials
- scenes/shots
- locked details
- allowed variations

## Prop package
For important recurring props:
- prop ID
- owner
- purpose
- dimensions / scale
- materials
- front/side/back/isometric as useful
- functional states
- damage states
- scene usage
- continuity rules

## Environment package
For important sets:
- environment ID
- establishing view
- spatial description
- landmark locations
- major furniture
- doors/windows
- time of day
- lighting
- palette/materials
- blocking zones
- camera zones
- continuity rules

## Asset filename convention
Use:
`CATEGORY_PROJECT_ASSET_VARIANT.ext`

Examples:
- `CHAR_TYPE7_NEO_DUDE_MASTER.png`
- `CHAR_TYPE7_CHILD_EXPRESSIONS.png`
- `CHOREO_TYPE7_CHILD_MASTER.png`
- `ENV_TYPE7_TESSERACT_BRIDGE_MASTER.png`
- `PROP_TYPE7_STAR_MAP_MASTER.png`

Never use meaningless filenames like `image1.png`.
