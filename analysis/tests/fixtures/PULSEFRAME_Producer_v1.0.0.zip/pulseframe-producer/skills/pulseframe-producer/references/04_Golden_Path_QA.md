# PULSEFRAME Producer — Golden Path QA

## Golden Path
Audit → Understand → Lock Bible → Build Assets → Build Shot Plan → Build Manifest → QA → Deliver

## Pre-delivery validation

### Story
- Does every sequence support the concept?
- Are beginning, development, climax and ending coherent?
- Are visual metaphors consistent?

### Song
- Are sections real or clearly marked approximate?
- Were timestamps invented? They must not be.
- Are lyric cues mapped correctly?

### Character
- Same identity across sheets?
- Wardrobe changes intentional?
- Scale stable?
- Signature accessories present?

### Props
- Correct owner?
- Same design?
- Correct state?
- Prop exists only when story requires it?

### Environment
- Same spatial layout across relevant scenes?
- Landmark positions stable?
- Lighting/time changes motivated?

### Choreography
- Appropriate to anatomy/age/personality?
- Moves transition plausibly?
- Timing does not contradict song map?
- Visual sheet and written spec agree?

### Camera / blocking
- Screen direction coherent?
- Eyelines plausible?
- Axis changes documented?
- Entrances/exits consistent?

### Shot plan
- Stable IDs?
- Every referenced asset exists?
- Shot references point to canonical assets?
- No duplicate/conflicting shot IDs?

### Manifest
- Valid JSON
- Valid against schema
- Relative paths
- No missing referenced files
- Canonical IDs consistent

## Readiness state
Return one:
- READY
- READY WITH WARNINGS
- NOT READY

Never mark READY when required files or core relationships are unresolved.
