# Prompt Starters

- Build a complete PULSEFRAME production package from this song and lyrics.
- Here is my script and character art. Audit what I already have and create everything else PULSEFRAME needs.
- Create individual choreography packages for every character who should move or dance.
- Turn this story idea into three music-video concepts, then build the selected one into a PULSEFRAME package.
- Create a continuity-safe Production Bible from these character, prop and environment sheets.
- Create the shot plan, camera blocking, performance direction and machine-readable manifest for this project.
- I want QUICK PRODUCE. Make strong defaults and only ask questions that truly matter.
- Use PRODUCER MODE and let me choose style, choreography, camera language, wardrobe and world design.
